; Acitividad uno algortimos de ordenamiento 



; DEFINICI�N DE REGISTROS 
.def temp1 = r16
.def temp2 = r17
.def min_val = r18
.def counter = r19
.def outer_loop = r20 ;cuenta cu�ntas veces  recorre la lista completa.
.def inner_loop = r21 ; contador de parejas
.def swap_flag = r22
.def numero_inicial = r23

; Segmentos de RAM
.dseg
.org 0x0100
table_of_unsorted_numbers:    .byte 100
table_of_sorted_numbers_alg1:  .byte 100
table_of_sorted_numbers_alg2:  .byte 100

;Segmentos de flash 
.cseg
.org 0x0000
    rjmp main

main:
    ; 
    ldi temp1, high(RAMEND)
    out SPH, temp1
    ldi temp1, low(RAMEND)
    out SPL, temp1

    ; Uso de la GPIO para indicar que cuando inicia y finaliza el algoritmo de ordenamiento
    sbi DDRB, 5      

    ; 3. Generar los 100 n�meros originales
    rcall sub_generar_aleatorios

   ;ALGORITMO 1 (BUBBLE SORT) 
    sbi PORTB, 5      ; ENCENDER LED (Inicia Algoritmo 1)
    ldi ZL, low(table_of_sorted_numbers_alg1)
    ldi ZH, high(table_of_sorted_numbers_alg1)
    rcall sub_copiar_datos
    rcall algoritmo_bubble_sort
    cbi PORTB, 5      ; APAGAR LED (Fin Algoritmo 1)

    ; guardamos el dato mas peque�o ordenado en la EEprom
    lds r16, table_of_sorted_numbers_alg1 
    ldi r17, 0x00     
    rcall sub_escribir_eeprom

    ;  ALGORITMO 2 (SELECTION SORT) 
    sbi PORTB, 5      ; ENCENDER LED (Inicia Algoritmo 2)
    ldi ZL, low(table_of_sorted_numbers_alg2)
    ldi ZH, high(table_of_sorted_numbers_alg2)
    rcall sub_copiar_datos
    rcall algoritmo_selection_sort
    cbi PORTB, 5      ; APAGAR LED (Fin Algoritmo 2)

    ; guardamos el dato mas peque�o ordenado en la EEprom
    lds r16, table_of_sorted_numbers_alg2
    ldi r17, 0x01
    rcall sub_escribir_eeprom

fin_programa:
    rjmp fin_programa

; subrutinas poara generar los numeros, desarrollo de los algorimos y escritura de la EEPROM


sub_generar_aleatorios:
    ldi ZL, low(table_of_unsorted_numbers)
    ldi ZH, high(table_of_unsorted_numbers)
    ldi counter, 100
    ldi numero_inicial, 0x74 
gen_loop:
    subi numero_inicial, -12   ; Operaci�n ALU
    rol numero_inicial         ; Operaci�n ALU
    st Z+, numero_inicial      ; Escritura en SRAM
    dec counter
    brne gen_loop
    ret

sub_copiar_datos:
    ldi XL, low(table_of_unsorted_numbers)
    ldi XH, high(table_of_unsorted_numbers)
    ldi counter, 100
copy_loop:
    ld temp1, X+        ; Lectura de SRAM
    st Z+, temp1        ; Escritura en SRAM
    dec counter
    brne copy_loop
    ret

sub_escribir_eeprom:
    sbic EECR, EEPE     ; Esperar si la EEPROM est� ocupada
    rjmp sub_escribir_eeprom
    ldi r19, 0x00
    out EEARH, r19      
    out EEARL, r17      ; Direcci�n (0x00 o 0x01)
    out EEDR, r16       ; El dato (m�nimo de la tabla)
    sbi EECR, EEMPE     
    sbi EECR, EEPE      
    ret



	

; --- ALGORITMO 1: BUBBLE SORT ---
algoritmo_bubble_sort:
    ldi outer_loop, 100
b_ext:
    ldi ZL, low(table_of_sorted_numbers_alg1)
    ldi ZH, high(table_of_sorted_numbers_alg1)
    clr swap_flag
    ldi inner_loop, 99
b_int:
    ld temp1, Z+
    ld temp2, Z
    cp temp2, temp1     ; Comparaci�n ALU
    brsh b_no_swap
    st Z, temp1         ; Intercambio en SRAM
    st -Z, temp2
    ld temp2, Z+
    ldi swap_flag, 1
b_no_swap:
    dec inner_loop
    brne b_int
    tst swap_flag
    breq b_done
    dec outer_loop
    brne b_ext
b_done:
    ret

; --- ALGORITMO 2: SELECTION SORT ---
algoritmo_selection_sort:
    ldi outer_loop, 99
    ldi XL, low(table_of_sorted_numbers_alg2)
    ldi XH, high(table_of_sorted_numbers_alg2)
s_ext:
    mov ZL, XL
    mov ZH, XH
    ld min_val, Z+
    mov YL, XL
    mov YH, XH
    mov inner_loop, outer_loop
s_int:
    ld temp1, Z+
    cp temp1, min_val   ; B�squeda del m�nimo (ALU)
    brsh s_next
    mov min_val, temp1
    mov YL, ZL
    mov YH, ZH
    sbiw YH:YL, 1       ; Ajuste de puntero Y (ALU 16-bits)
s_next:
    dec inner_loop
    brne s_int
    ld temp2, X         ; Swap final de pasada
    st X+, min_val
    st Y, temp2
    dec outer_loop
    brne s_ext
    ret